package com.example.notessqlite


import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class NotasDateBaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION){

        companion object{
            private const val DATABASE_NAME = "notaApp.db"
            private const val DATABASE_VERSION = 1
            private const val TABLE_NAME = "allnotes"
            private const val COLUMN_ID = "id"
            private const val COLUMN_TITLE = "title"
            private const val COLUMN_CONTENT = "content"
        }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = "CREATE TABLE $TABLE_NAME ($COLUMN_ID INTEGER PRIMARY KEY, $COLUMN_TITLE TEXT, $COLUMN_CONTENT TEXT)"
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        val dropTableQuery = "DROP TABLE IF EXISTS $TABLE_NAME"
        db?.execSQL(dropTableQuery)
        onCreate(db)


    }

    fun insertNotas(notas: Notas){
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COLUMN_TITLE, notas.title)
            put(COLUMN_CONTENT, notas.content)
        }
        db.insert(TABLE_NAME, null, values)
        db.close()
    }

    fun getAllNotes(): List<Notas> {
        val notesList = mutableListOf<Notas>()
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_NAME"
        val cursor = db.rawQuery(query, null)

        while (cursor.moveToNext()){
            val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
            val title = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE))
            val content = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CONTENT))

            val notas = Notas(id, title, content)
            notesList.add(notas)
        }
        cursor.close()
        db.close()
        return notesList
    }

fun updateNotas(notas: Notas){
    val db = writableDatabase
    val values = ContentValues().apply {
        put(COLUMN_TITLE, notas.title)
        put(COLUMN_CONTENT, notas.content)
    }
    val whereClause = "$COLUMN_ID = ?"
    val whereArgs = arrayOf(notas.id.toString())
    db.update(TABLE_NAME, values, whereClause, whereArgs)
    db.close()

}

    fun getNotasById(notasID: Int): Notas{
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_NAME WHERE $COLUMN_ID = $notasID"
        val cursor = db.rawQuery(query, null)
        cursor.moveToFirst()

        val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID))
        val title = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TITLE))
        val content = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CONTENT))

        cursor.close()
        db.close()
        return Notas(id, title, content)

    }

    fun deleteNotas(notasID: Int){
        val db = writableDatabase
        val whereClause = "$COLUMN_ID = ?"
        val whereArgs = arrayOf(notasID.toString())
        db.delete(TABLE_NAME, whereClause, whereArgs)
        db.close()
    }


}

