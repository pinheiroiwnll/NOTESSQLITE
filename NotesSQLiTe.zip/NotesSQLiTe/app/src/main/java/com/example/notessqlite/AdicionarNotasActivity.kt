package com.example.notessqlite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.notessqlite.databinding.ActivityAdicionarNotasBinding

class AdicionarNotasActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdicionarNotasBinding
    private lateinit var db: NotasDateBaseHelper


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdicionarNotasBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = NotasDateBaseHelper (this)

        binding.saveButton.setOnClickListener{
            val title = binding.titleEditText.text.toString()
            val content = binding.contentEditText.text.toString()
            val Notas = Notas(0, title, content)
            db.insertNotas(Notas)
            finish()
            Toast.makeText(this, "Nota Salva com Sucesso!", Toast.LENGTH_SHORT).show()
        }
    }


}