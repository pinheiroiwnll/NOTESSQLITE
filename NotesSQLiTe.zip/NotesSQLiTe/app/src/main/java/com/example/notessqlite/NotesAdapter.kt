package com.example.notessqlite

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class NotesAdapter(private var notes: List<Notas>, context: Context) :
    RecyclerView.Adapter<NotesAdapter.NotasViewHolder>() {

    private val db: NotasDateBaseHelper = NotasDateBaseHelper(context)

    class NotasViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.titleTextView)
        val contentTextView: TextView = itemView.findViewById(R.id.contentTextView)
        val updateButton: ImageView = itemView.findViewById(R.id.updateButton)
        val deleteButton: ImageView = itemView.findViewById(R.id.deleteButton)


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotasViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.note_item, parent, false)
        return NotasViewHolder(view)
    }

    override fun getItemCount(): Int = notes.size


    override fun onBindViewHolder(holder: NotasViewHolder, position: Int) {
        val note = notes [position]
        holder.titleTextView.text = note.title
        holder.contentTextView.text = note.title

        holder.updateButton.setOnClickListener{
            val intent = Intent(holder.itemView.context, UpdateNoteActivity::class.java).apply {
                putExtra("note_id", note.id)
            }
            holder.itemView.context.startActivity(intent)
        }

        holder.deleteButton.setOnClickListener{
            db.deleteNotas(note.id)
            refreshData(db.getAllNotes())
            Toast.makeText(holder.itemView.context, "Nota Deletada", Toast.LENGTH_SHORT).show()
        }


    }

    fun refreshData(NewNotes: List<Notas>){
        notes = NewNotes
        notifyDataSetChanged()
    }

}
