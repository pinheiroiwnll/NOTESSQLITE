package com.example.notessqlite

data class Notas(val id: Int, val title: String, val content: String)
