package com.example.notessqlite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.notessqlite.databinding.ActivityUpdateNoteBinding

class UpdateNoteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUpdateNoteBinding
    private lateinit var db: NotasDateBaseHelper
    private var notasId: Int = -1


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUpdateNoteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = NotasDateBaseHelper(this)

        notasId = intent.getIntExtra("notas_id", -1)
        if (notasId == -1) {
            finish()
            return
        }

        val notas = db.getNotasById(notasId)
        binding.updateTitleEditText.setText(notas.title)
        binding.updateContentEditText.setText(notas.content)

        binding.updateSaveButton.setOnClickListener{
            val newTitle = binding.updateTitleEditText.text.toString()
            val newContent = binding.updateContentEditText.toString()
            val updateNotas = Notas(notasId, newTitle, newContent)
            db.updateNotas(updateNotas)
            finish()
            Toast.makeText(this, "As Mudanças foram salvas!", Toast.LENGTH_SHORT).show()
        }


    }
}